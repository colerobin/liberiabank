jQuery(document).ready(function() {
  jQuery('#myCarousel').carousel({ interval: 3000, cycle: true });
});
